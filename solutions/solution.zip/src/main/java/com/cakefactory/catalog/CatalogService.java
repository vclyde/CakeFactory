package com.cakefactory.catalog;

/**
 *
 * @author cvelasquez
 */
public interface CatalogService {

	Iterable<Item> getItems();
}
